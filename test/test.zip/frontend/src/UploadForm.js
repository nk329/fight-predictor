import React, { useState } from "react";

function UploadForm() {
    const [imageA, setImageA] = useState(null);
    const [imageB, setImageB] = useState(null);

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!imageA || !imageB) {
            alert("두 이미지를 모두 선택해주세요.");
            return;
        }

        const formData = new FormData();
        formData.append("imageA", imageA);
        formData.append("imageB", imageB);

        try {
            const response = await fetch("http://localhost:8000/upload", {
                method: "POST",
                body: formData,
            });

            const data = await response.json();
            setResult(data);
        }
        catch (err) { console.error(err); }

    };

    return (
        <div>
          <h2>이미지 업로드</h2>
          <form onSubmit={handleSubmit}>
            <input type="file" accept="image/*" onChange={(e) => setImageA(e.target.files[0])} />
            <input type="file" accept="image/*" onChange={(e) => setImageB(e.target.files[0])} />
            <button type="submit">업로드</button>
          </form>
        </div>
      );
}

export default UploadForm;