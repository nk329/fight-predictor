import logo from './logo.svg';
import './App.css';
import UploadForm from "./UploadForm";

function App() {
  return (
    <div style={{ padding: "20px", fontFamily: "sans-serif" }}>
      <UploadForm />
    </div>
  );
}

export default App;
