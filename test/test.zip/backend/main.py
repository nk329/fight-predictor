from fastapi import FastAPI, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
import shutil
import os

from mediapipe_extract import get_mediapipe_info

app = FastAPI()

# Allow requests from your frontend (adjust origin as needed)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # or your React URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Ensure 'uploads' folder exists
os.makedirs("uploads", exist_ok=True)

@app.post("/upload")
async def upload_images(imageA: UploadFile = File(...), imageB: UploadFile = File(...)):
    for image in [imageA, imageB]:
        file_location = f"uploads/{image.filename}"
        with open(file_location, "wb") as f:
            shutil.copyfileobj(image.file, f)

    pathA = f"uploads/{imageA.filename}"
    pathB = f"uploads/{imageB.filename}"
    data = get_mediapipe_info(pathA, pathB)

    to_str = "height_diff: " + data[0] + " weight_diff: " + data[1] + " reach_diff: " + data[2]

    return {"message": "Files uploaded successfully"}