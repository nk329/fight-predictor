import torch
import torch.nn as nn

class MLP(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(3, 32),
            nn.ReLU(),
            nn.Linear(32, 16),
            nn.ReLU(),
            nn.Linear(16, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        return self.net(x)

def load_model(model_path="model.pt"):
    model = MLP()
    model.load_state_dict(torch.load(model_path, map_location=torch.device("cpu")))
    model.eval()
    return model

def predict_winner(model, height_diff, weight_diff, reach_diff):
    input_tensor = torch.tensor([[height_diff, weight_diff, reach_diff]], dtype=torch.float32)

    with torch.no_grad():
        prob = model(input_tensor).item()

    return prob
